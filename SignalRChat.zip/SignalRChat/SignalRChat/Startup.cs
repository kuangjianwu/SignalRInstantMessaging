﻿using Microsoft.Owin;
using Owin;
[assembly: OwinStartup(typeof(SignalRChat.Startup))]
namespace SignalRChat
{
    public class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            //任何连接或集线器线路配置应该在这里
            app.MapSignalR();
        }
    }
}